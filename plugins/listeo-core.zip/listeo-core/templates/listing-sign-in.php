<!-- <div class="notification notice large margin-bottom-55">
	<h4><?php esc_html_e('Don\'t Have an Account?','listeo_core'); ?></h4>
	<p><?php esc_html_e('If you don\'t have an account please register using form below. A password will be automatically emailed to you.','listeo_core'); ?></p>
</div> -->